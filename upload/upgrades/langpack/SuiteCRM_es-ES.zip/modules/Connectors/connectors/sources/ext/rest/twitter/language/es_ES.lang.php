<?php

    if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

    $connector_strings = array (
        //Vardef labels
        'LBL_LICENSING_INFO' => '<table border="0" cellspacing="1"> <tr><th valign="top" width="35%" class="dataLabel"> Información de la aplicación de Twitter</th></tr> <tr><td width="35%" class="dataLabel">, necesitará crear una cuenta de desarrolladores de Twitter y aplicación Para registrarse</td></tr></table>',
        //Configuration labels
        'consumer_key' => 'Clave del Consumidor',
        'consumer_secret' => 'Secreto del Consumidor',
    );


?>
