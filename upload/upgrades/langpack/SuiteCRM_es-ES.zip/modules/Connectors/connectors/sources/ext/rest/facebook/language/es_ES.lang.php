<?php

    if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

    $connector_strings = array (
        //Vardef labels
        'LBL_LICENSING_INFO' => '<table border="0" cellspacing="1"> <tr><th valign="top" width="35%" class="dataLabel"> Información de la aplicación de Facebook</th></tr> <tr><td width="35%" class="dataLabel"> que tendrá que crear una aplicación de facebook, conseguir uno <a href=https://developers.facebook.com/?ref=pf"> aquí</a></td></tr></table>',

        //Configuration labels
        'appid' => 'Facebook App ID ',
        'secret' => 'Secreto de la aplicación de Facebook ',
    );

?>